pyglet.graphics.vertexattribute
===============================

.. automodule:: pyglet.graphics.vertexattribute
  :members:
  :undoc-members:
