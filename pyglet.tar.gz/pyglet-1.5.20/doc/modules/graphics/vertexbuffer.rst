pyglet.graphics.vertexbuffer
============================

.. automodule:: pyglet.graphics.vertexbuffer
  :members:
  :undoc-members:
