pyglet.graphics
===============

.. rubric:: Submodules

.. toctree::
   :maxdepth: 1

   allocation
   vertexattribute
   vertexbuffer
   vertexdomain

.. rubric:: Details

.. automodule:: pyglet.graphics
  :members:
  :undoc-members:
