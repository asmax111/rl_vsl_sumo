pyglet.text
===========

.. rubric:: Submodules

.. toctree::
   :maxdepth: 1

   caret
   document
   layout

.. rubric:: Details

.. automodule:: pyglet.text
  :members:
  :undoc-members:
