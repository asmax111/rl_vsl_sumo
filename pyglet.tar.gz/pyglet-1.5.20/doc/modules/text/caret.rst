pyglet.text.caret
=================

.. automodule:: pyglet.text.caret
  :members:
  :undoc-members:
