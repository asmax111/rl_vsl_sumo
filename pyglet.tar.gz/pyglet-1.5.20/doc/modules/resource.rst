pyglet.resource
===============

.. automodule:: pyglet.resource
  :members:
  :undoc-members:

.. autofunction:: reindex
.. autofunction:: file
.. autofunction:: location
.. autofunction:: add_font
.. autofunction:: image
.. autofunction:: animation
.. autofunction:: get_cached_image_names
.. autofunction:: get_cached_animation_names
.. autofunction:: get_texture_bins
.. autofunction:: media
.. autofunction:: texture
.. autofunction:: html
.. autofunction:: attributed
.. autofunction:: text
.. autofunction:: get_cached_texture_names
